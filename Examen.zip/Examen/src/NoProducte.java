public class NoProducte extends Exception{
    public NoProducte(String message) {
        super(message);
    }
}
