import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class NoProducte extends Exception{
    public NoProducte(String message) {
        super(message);
    }
}


